/**
 * FarmWSSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package controler.communication.farm.axis;

public class FarmWSSoapBindingSkeleton implements controler.communication.farm.axis.FarmWS, org.apache.axis.wsdl.Skeleton {
	private controler.communication.farm.axis.FarmWS impl;
	private static java.util.Map _myOperations = new java.util.Hashtable();
	private static java.util.Collection _myOperationsList = new java.util.ArrayList();

	/**
	 * Returns List of OperationDesc objects with this name
	 */
	public static java.util.List getOperationDescByName(java.lang.String methodName) {
		return (java.util.List)_myOperations.get(methodName);
	}

	/**
	 * Returns Collection of OperationDescs
	 */
	public static java.util.Collection getOperationDescs() {
		return _myOperationsList;
	}

	static {
		org.apache.axis.description.OperationDesc _oper;
		org.apache.axis.description.FaultDesc _fault;
		org.apache.axis.description.ParameterDesc [] _params;
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "initID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"), long.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "name"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("register", _params, new javax.xml.namespace.QName("http://axis.farm.communication.controler", "registerReturn"));
		_oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "register"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("register") == null) {
			_myOperations.put("register", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("register")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "initID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"), long.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("unregister", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "unregister"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("unregister") == null) {
			_myOperations.put("unregister", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("unregister")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("getActionFromControler", _params, new javax.xml.namespace.QName("http://axis.farm.communication.controler", "getActionFromControlerReturn"));
		_oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "getActionFromControler"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("getActionFromControler") == null) {
			_myOperations.put("getActionFromControler", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("getActionFromControler")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("getTestRun", _params, new javax.xml.namespace.QName("http://axis.farm.communication.controler", "getTestRunReturn"));
		_oper.setReturnType(new javax.xml.namespace.QName("http://farm.transport.simobjects", "TestrunAxis"));
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "getTestRun"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("getTestRun") == null) {
			_myOperations.put("getTestRun", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("getTestRun")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("loadedSim", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "loadedSim"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("loadedSim") == null) {
			_myOperations.put("loadedSim", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("loadedSim")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("startedSim", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "startedSim"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("startedSim") == null) {
			_myOperations.put("startedSim", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("startedSim")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("abortedSim", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "abortedSim"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("abortedSim") == null) {
			_myOperations.put("abortedSim", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("abortedSim")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("finishedSim", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "finishedSim"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("finishedSim") == null) {
			_myOperations.put("finishedSim", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("finishedSim")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "simResult"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://farm.transport.simobjects", "SimResultAxis"), simobjects.transport.farm.SimResultAxis.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("addSimResult", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "addSimResult"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("addSimResult") == null) {
			_myOperations.put("addSimResult", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("addSimResult")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "message"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("addSimLogMessage", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "addSimLogMessage"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("addSimLogMessage") == null) {
			_myOperations.put("addSimLogMessage", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("addSimLogMessage")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "stats"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://farm.transport.simobjects", "SimStatisticsAxis"), simobjects.transport.farm.SimStatisticsAxis.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("addSimStatistics", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "addSimStatistics"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("addSimStatistics") == null) {
			_myOperations.put("addSimStatistics", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("addSimStatistics")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "trID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "simState"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://farm.transport.simobjects", "SimStateAxis"), simobjects.transport.farm.SimStateAxis.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("setSimState", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "setSimState"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("setSimState") == null) {
			_myOperations.put("setSimState", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("setSimState")).add(_oper);
		_params = new org.apache.axis.description.ParameterDesc [] {
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
				new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "receiverState"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://farm.transport.simobjects", "ReceiverStateAxis"), simobjects.transport.farm.ReceiverStateAxis.class, false, false), 
		};
		_oper = new org.apache.axis.description.OperationDesc("setReceiverState", _params, null);
		_oper.setElementQName(new javax.xml.namespace.QName("http://axis.farm.communication.controler", "setReceiverState"));
		_oper.setSoapAction("");
		_myOperationsList.add(_oper);
		if (_myOperations.get("setReceiverState") == null) {
			_myOperations.put("setReceiverState", new java.util.ArrayList());
		}
		((java.util.List)_myOperations.get("setReceiverState")).add(_oper);
	}

	public FarmWSSoapBindingSkeleton() {
		this.impl = new controler.communication.farm.axis.FarmWSSoapBindingImpl();
	}

	public FarmWSSoapBindingSkeleton(controler.communication.farm.axis.FarmWS impl) {
		this.impl = impl;
	}
	public int register(long initID, java.lang.String name) throws java.rmi.RemoteException
	{
		int ret = impl.register(initID, name);
		return ret;
	}

	public void unregister(int receiverID, long initID) throws java.rmi.RemoteException
	{
		impl.unregister(receiverID, initID);
	}

	public int getActionFromControler(int receiverID) throws java.rmi.RemoteException
	{
		int ret = impl.getActionFromControler(receiverID);
		return ret;
	}

	public simobjects.transport.farm.TestrunAxis getTestRun(int receiverID) throws java.rmi.RemoteException
	{
		simobjects.transport.farm.TestrunAxis ret = impl.getTestRun(receiverID);
		return ret;
	}

	public void loadedSim(int receiverID, int trID) throws java.rmi.RemoteException
	{
		impl.loadedSim(receiverID, trID);
	}

	public void startedSim(int receiverID, int trID) throws java.rmi.RemoteException
	{
		impl.startedSim(receiverID, trID);
	}

	public void abortedSim(int receiverID, int trID) throws java.rmi.RemoteException
	{
		impl.abortedSim(receiverID, trID);
	}

	public void finishedSim(int receiverID, int trID) throws java.rmi.RemoteException
	{
		impl.finishedSim(receiverID, trID);
	}

	public void addSimResult(int receiverID, int trID, simobjects.transport.farm.SimResultAxis simResult) throws java.rmi.RemoteException
	{
		impl.addSimResult(receiverID, trID, simResult);
	}

	public void addSimLogMessage(int receiverID, int trID, java.lang.String message) throws java.rmi.RemoteException
	{
		impl.addSimLogMessage(receiverID, trID, message);
	}

	public void addSimStatistics(int receiverID, int trID, simobjects.transport.farm.SimStatisticsAxis stats) throws java.rmi.RemoteException
	{
		impl.addSimStatistics(receiverID, trID, stats);
	}

	public void setSimState(int receiverID, int trID, simobjects.transport.farm.SimStateAxis simState) throws java.rmi.RemoteException
	{
		impl.setSimState(receiverID, trID, simState);
	}

	public void setReceiverState(int receiverID, simobjects.transport.farm.ReceiverStateAxis receiverState) throws java.rmi.RemoteException
	{
		impl.setReceiverState(receiverID, receiverState);
	}

}
