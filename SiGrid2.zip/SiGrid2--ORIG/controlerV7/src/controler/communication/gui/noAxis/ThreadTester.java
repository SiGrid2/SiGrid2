package controler.communication.gui.noAxis;

import controler.communication.gui.axis.GuiWebservice;

public class ThreadTester {

	public static void main(String[] args) {
		GuiWebservice ws = new GuiWebservice();
		BatchControlerThread thread = new BatchControlerThread (ws, args[0]);
		thread.run();
	}

}
