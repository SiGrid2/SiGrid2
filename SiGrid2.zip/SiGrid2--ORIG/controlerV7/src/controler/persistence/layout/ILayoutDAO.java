package controler.persistence.layout;

import simobjects.Layout;
import controler.persistence.IGenericDAO;


/**
 * DAO interface of entity layout, extending and parametrizes superinterface IGenericDAO
 * 
 * @author Dirk Holzapfel
 * @version 1.0
 */
public interface ILayoutDAO extends IGenericDAO<Layout, Integer > {

}//end of interface
