package controler.persistence.layout;

import simobjects.Layout;
import controler.persistence.GenericJPADAO;


/**
 * JPA implementation of ILayoutDAO
 * 
 * @author Dirk Holzapfel
 * @version 1.0
 */
public class LayoutDAOJPA extends GenericJPADAO <Layout, Integer> implements ILayoutDAO {

}//end of class
