package controler.persistence.simresult;

import simobjects.SimResult;
import controler.persistence.IGenericDAO;


/**
 * DAO interface of entity simresult, extending and parametrizes superinterface IGenericDAO
 * 
 * @author Dirk Holzapfel
 * @version 1.0
 */
public interface ISimResultDAO extends IGenericDAO<SimResult, Integer >{

}//end of interface
