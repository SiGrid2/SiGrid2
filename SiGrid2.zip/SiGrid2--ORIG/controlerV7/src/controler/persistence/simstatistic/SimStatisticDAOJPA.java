package controler.persistence.simstatistic;


import controler.persistence.GenericJPADAO;
import simobjects.SimStatistics;


/**
 * JPA implementation of ISimStatisticDAO
 * 
 * @author Dirk Holzapfel
 * @version 1.0
 */
public class SimStatisticDAOJPA extends GenericJPADAO<SimStatistics, Integer> implements ISimStatisticDAO {

}//end of class
