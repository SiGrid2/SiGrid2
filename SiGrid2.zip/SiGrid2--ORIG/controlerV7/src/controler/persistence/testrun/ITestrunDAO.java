package controler.persistence.testrun;

import simobjects.TestRun;
import controler.persistence.IGenericDAO;


/**
 * DAO interface of entity testrun, extending and parametrizes superinterface IGenericDAO
 * 
 * @author Dirk Holzapfel
 * @version 1.0
 */
public interface ITestrunDAO extends IGenericDAO<TestRun, Integer > {

}//end of interface
