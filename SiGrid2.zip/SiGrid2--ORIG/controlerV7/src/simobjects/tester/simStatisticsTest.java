package simobjects.tester;

import simobjects.SimStatistics;

/**
 * Class for evaluating class simStatistics
 * 
 * @author Dirk Holzapfel
 * @version 1.0
 */
public class simStatisticsTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {


		SimStatistics stats = new SimStatistics (-5,10,10);
		for (int i = 1 ; i <=10 ; i++) {
			System.out.println(i);
			stats.addEarning(i);
		}

		stats.printToConsole();
	}

}
