/**
 * JobAxis.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package simobjects.transport.farm;

public class JobAxis  implements java.io.Serializable {
    private int dasd;

    private int duration;

    private int earning;

    private int id;

    private int penalty;

    private int relCat;

    private int speedCat;

    private int startTime;

    public JobAxis() {
    }

    public JobAxis(
           int dasd,
           int duration,
           int earning,
           int id,
           int penalty,
           int relCat,
           int speedCat,
           int startTime) {
           this.dasd = dasd;
           this.duration = duration;
           this.earning = earning;
           this.id = id;
           this.penalty = penalty;
           this.relCat = relCat;
           this.speedCat = speedCat;
           this.startTime = startTime;
    }


    /**
     * Gets the dasd value for this JobAxis.
     * 
     * @return dasd
     */
    public int getDasd() {
        return dasd;
    }


    /**
     * Sets the dasd value for this JobAxis.
     * 
     * @param dasd
     */
    public void setDasd(int dasd) {
        this.dasd = dasd;
    }


    /**
     * Gets the duration value for this JobAxis.
     * 
     * @return duration
     */
    public int getDuration() {
        return duration;
    }


    /**
     * Sets the duration value for this JobAxis.
     * 
     * @param duration
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }


    /**
     * Gets the earning value for this JobAxis.
     * 
     * @return earning
     */
    public int getEarning() {
        return earning;
    }


    /**
     * Sets the earning value for this JobAxis.
     * 
     * @param earning
     */
    public void setEarning(int earning) {
        this.earning = earning;
    }


    /**
     * Gets the id value for this JobAxis.
     * 
     * @return id
     */
    public int getId() {
        return id;
    }


    /**
     * Sets the id value for this JobAxis.
     * 
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }


    /**
     * Gets the penalty value for this JobAxis.
     * 
     * @return penalty
     */
    public int getPenalty() {
        return penalty;
    }


    /**
     * Sets the penalty value for this JobAxis.
     * 
     * @param penalty
     */
    public void setPenalty(int penalty) {
        this.penalty = penalty;
    }


    /**
     * Gets the relCat value for this JobAxis.
     * 
     * @return relCat
     */
    public int getRelCat() {
        return relCat;
    }


    /**
     * Sets the relCat value for this JobAxis.
     * 
     * @param relCat
     */
    public void setRelCat(int relCat) {
        this.relCat = relCat;
    }


    /**
     * Gets the speedCat value for this JobAxis.
     * 
     * @return speedCat
     */
    public int getSpeedCat() {
        return speedCat;
    }


    /**
     * Sets the speedCat value for this JobAxis.
     * 
     * @param speedCat
     */
    public void setSpeedCat(int speedCat) {
        this.speedCat = speedCat;
    }


    /**
     * Gets the startTime value for this JobAxis.
     * 
     * @return startTime
     */
    public int getStartTime() {
        return startTime;
    }


    /**
     * Sets the startTime value for this JobAxis.
     * 
     * @param startTime
     */
    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof JobAxis)) return false;
        JobAxis other = (JobAxis) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.dasd == other.getDasd() &&
            this.duration == other.getDuration() &&
            this.earning == other.getEarning() &&
            this.id == other.getId() &&
            this.penalty == other.getPenalty() &&
            this.relCat == other.getRelCat() &&
            this.speedCat == other.getSpeedCat() &&
            this.startTime == other.getStartTime();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getDasd();
        _hashCode += getDuration();
        _hashCode += getEarning();
        _hashCode += getId();
        _hashCode += getPenalty();
        _hashCode += getRelCat();
        _hashCode += getSpeedCat();
        _hashCode += getStartTime();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(JobAxis.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://farm.transport.simobjects", "JobAxis"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dasd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "dasd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duration");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "duration"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("earning");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "earning"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("penalty");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "penalty"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relCat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "relCat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("speedCat");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "speedCat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://farm.transport.simobjects", "startTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
