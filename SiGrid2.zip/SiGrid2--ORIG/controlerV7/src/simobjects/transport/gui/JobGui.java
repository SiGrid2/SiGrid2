package simobjects.transport.gui;

import java.io.Serializable;

public class JobGui implements Serializable {
	
	
	private static final long serialVersionUID = 7309226387595660967L;
	private int id;
	private int earning;
	private int dasd;
	private int startTime;
	private int duration;
	private int relCat;
	private int speedCat;
	private int penalty;
	
	
	public JobGui() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getEarning() {
		return earning;
	}


	public void setEarning(int earning) {
		this.earning = earning;
	}


	public int getDasd() {
		return dasd;
	}


	public void setDasd(int dasd) {
		this.dasd = dasd;
	}


	public int getStartTime() {
		return startTime;
	}


	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}


	public int getDuration() {
		return duration;
	}


	public void setDuration(int duration) {
		this.duration = duration;
	}


	public int getRelCat() {
		return relCat;
	}


	public void setRelCat(int relCat) {
		this.relCat = relCat;
	}


	public int getSpeedCat() {
		return speedCat;
	}


	public void setSpeedCat(int speedCat) {
		this.speedCat = speedCat;
	}


	public int getPenalty() {
		return penalty;
	}


	public void setPenalty(int penalty) {
		this.penalty = penalty;
	}
	
	

	

}
