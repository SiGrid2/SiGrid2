package simobjects.transport.gui;

import java.io.Serializable;



public class MatrixGui implements Serializable{
	
	
	private static final long serialVersionUID = -8986526593658412052L;
	private int numJobs; 
	private int numServer; 
	private String matrixForDB;
	
	
	public MatrixGui() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getNumJobs() {
		return numJobs;
	}


	public void setNumJobs(int numJobs) {
		this.numJobs = numJobs;
	}


	public int getNumServer() {
		return numServer;
	}


	public void setNumServer(int numServer) {
		this.numServer = numServer;
	}


	public String getMatrixForDB() {
		return matrixForDB;
	}


	public void setMatrixForDB(String matrixForDB) {
		this.matrixForDB = matrixForDB;
	}
	
	
	
	

}
