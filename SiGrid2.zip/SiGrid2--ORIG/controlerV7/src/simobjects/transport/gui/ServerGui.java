package simobjects.transport.gui;

public class ServerGui {
	
	private int id;
	private int cost;
	private int dasd;
	private int relCat;
	private int speedCat;
	
	
	public ServerGui() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getCost() {
		return cost;
	}


	public void setCost(int cost) {
		this.cost = cost;
	}


	public int getDasd() {
		return dasd;
	}


	public void setDasd(int dasd) {
		this.dasd = dasd;
	}


	public int getRelCat() {
		return relCat;
	}


	public void setRelCat(int relCat) {
		this.relCat = relCat;
	}


	public int getSpeedCat() {
		return speedCat;
	}


	public void setSpeedCat(int speedCat) {
		this.speedCat = speedCat;
	}
	
	
	
	

}
