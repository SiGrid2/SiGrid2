package simobjects.transport.gui;

import java.io.Serializable;



public class SimFarmGui implements Serializable{
	
	
	
	private static final long serialVersionUID = 3186240427149909825L;
	private int 		id;
	private long		firstRegAtMs;	
	private long		upSinceMS;	
	private int			status; // (idle, paused, or running Tr #343)
	private long 		initID;
	private String name;
	
	public SimFarmGui() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public long getFirstRegAtMs() {
		return firstRegAtMs;
	}

	public void setFirstRegAtMs(long firstRegAtMs) {
		this.firstRegAtMs = firstRegAtMs;
	}

	public long getUpSinceMS() {
		return upSinceMS;
	}

	public void setUpSinceMS(long upSinceMS) {
		this.upSinceMS = upSinceMS;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public long getInitID() {
		return initID;
	}

	public void setInitID(long initID) {
		this.initID = initID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	

}
