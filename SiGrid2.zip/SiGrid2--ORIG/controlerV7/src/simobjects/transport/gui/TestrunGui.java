package simobjects.transport.gui;

import java.io.PrintStream;
import java.io.Serializable;



public class TestrunGui implements Serializable {


	private static final long serialVersionUID = -6122428572589377336L;
	private int 	id;	
	private int 	layoutId;	
	private int 	algorithmId;
	private String  name;
	private long 	statsStart;
	private long 	statsEnd;
	private int  	statsNumFields;


	public TestrunGui() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public int getLayoutId() {
		return layoutId;
	}


	public void setLayoutId(int layoutId) {
		this.layoutId = layoutId;
	}


	public int getAlgorithmId() {
		return algorithmId;
	}


	public void setAlgorithmId(int algorithmId) {
		this.algorithmId = algorithmId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public long getStatsStart() {
		return statsStart;
	}


	public void setStatsStart(long statsStart) {
		this.statsStart = statsStart;
	}


	public long getStatsEnd() {
		return statsEnd;
	}


	public void setStatsEnd(long statsEnd) {
		this.statsEnd = statsEnd;
	}


	public int getStatsNumFields() {
		return statsNumFields;
	}


	public void setStatsNumFields(int statsNumFields) {
		this.statsNumFields = statsNumFields;
	}

	public void dump (PrintStream stream) {
		stream.println("id="+id);
		stream.println("layoutId="+layoutId);
		stream.println("algorithmId="+algorithmId);
		stream.println("name="+name);
		stream.println("statsStart="+statsStart);
		stream.println("statsEnd="+statsEnd);
		stream.println("statsNumFields="+statsNumFields);
	}



}
