/**
 * 
 */
package tools;

/**
 * @author chris
 *
 */
public class InstalllTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
