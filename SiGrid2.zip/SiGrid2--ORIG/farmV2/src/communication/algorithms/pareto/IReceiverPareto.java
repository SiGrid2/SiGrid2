package communication.algorithms.pareto;

/**
 * Interface for methods called from SimMaster on SimWorker 
 * 
 * @author Dirk Holzapfel
 * @version 1.0
 */
public interface IReceiverPareto {	

}//end of interface
