package communication.algorithms.pareto.rmi;

import java.rmi.Remote;


/**
 * Interface for RMI-Methods called from SimMaster on SimWorker 
 * 
 * @author Dirk Holzapfel
 * @version 1.0  
 */
public interface IReceiverParetoRMI extends Remote {

}//end of interface
